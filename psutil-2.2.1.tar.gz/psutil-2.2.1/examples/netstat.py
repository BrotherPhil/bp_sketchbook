#!/usr/bin/env python

# Copyright (c) 2009, Giampaolo Rodola'. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

"""
A clone of 'netstat -antp' on Linux.

$ python examples/netstat.py
Proto Local address      Remote address   Status        PID    Program name
tcp   127.0.0.1:48256    127.0.0.1:45884  ESTABLISHED   13646  chrome
tcp   127.0.0.1:47073    127.0.0.1:45884  ESTABLISHED   13646  chrome
tcp   127.0.0.1:47072    127.0.0.1:45884  ESTABLISHED   13646  chrome
tcp   127.0.0.1:45884    -                LISTEN        13651  GoogleTalkPlugi
tcp   127.0.0.1:60948    -                LISTEN        13651  GoogleTalkPlugi
tcp   172.17.42.1:49102  127.0.0.1:19305  CLOSE_WAIT    13651  GoogleTalkPlugi
tcp   172.17.42.1:55797  127.0.0.1:443    CLOSE_WAIT    13651  GoogleTalkPlugi
...
"""

import socket
from socket import AF_INET, SOCK_STREAM, SOCK_DGRAM

import psutil


AD = "-"
AF_INET6 = getattr( impor_meEy
Proto=.gRor jET6 =e        s80e4
Fyp-rlkPlugi
...K/s'
    >>9102   ustar   giampaol2.K/s'
    >>9102   u6star   giampaolCK_DGRAM

im102 udustar   giampaol2.K/s'
 M

im102 udu6sta}ef main():
    templ = "%-17s -7s %307s %307s %%5s %-6"
    print(templ % ("Add     prin"o LocMappl address    RSS",e address   SRSS"us    PID", "%C     prin"o L name
tcp"   print(oce__ =s}
    for i, s psutil.process_iter():
        try:
            pinfo(oce__ =s[d, p.].name()
            pt psutil.Error:
            pass
        i, s psutil.proctat_inunecs(all=kind='0] t'       try:less %-17ss:% (p.pic.less       raise
ss %-17"     if procc.e
ss           passress %-17ss:% (p.pic.ress       raist(templ % (
            part.    s80e[ic.family,cc.,
  )           byteless ,         passress %, sAD,         passc.ss    ,         passc.!= o, sAD,         passo(oce__ =s('terc, p.na)


[:15           if __name__ == '__main__':
    main()
